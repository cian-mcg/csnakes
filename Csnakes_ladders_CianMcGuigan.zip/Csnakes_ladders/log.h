#ifndef _SNAKES_LADDERS_LOG_H_
#define _SNAKES_LADDERS_LOG_H_

/*
    uncommenting the following line
    enables/disables logging to standard output
*/
// #define LOG_STDOUT

// open the log output file in append mode?
// #define LOGFILE_APPEND

int open_log(char *logpath);

int log_line(char *fmt, ...);

int close_log();

#endif

