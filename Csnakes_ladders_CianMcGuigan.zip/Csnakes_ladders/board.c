#include <stdlib.h>
#include "board.h"
#include "log.h"

board_t init_board(int size) {
    int i;
    board_t board;
    cell_t *next;

    // allocate memory for the board
    board = calloc(sizeof(struct board), 1);
    next = &(board->cells);

    // populate the board cells
    for (i = 1; i <= size; i++) {
        // initialize/create the cell for the current index
        *next = init_cell(i);
        next = &((*next)->next);
        board->size++;
    }
    return board;
}

cell_t init_cell(int index) {
    /*
        allocate memory space for the cell
        and populate its members
    */
    cell_t cell = calloc(sizeof(struct cell), 1);
    cell->index = index;

    return cell;
}

snake_t init_snake(int length) {
    /*
        allocate memory space for the snake structure
        and populate is members
    */
    snake_t snake = calloc(sizeof(struct snake_ladder), 1);
    snake->length = length;
    snake->direction = BACKWARDS;

    return snake;
}

ladder_t init_ladder(int length) {
    /*
        allocate memory space for the ladder structure
        and populate its members
    */
    ladder_t ladder = calloc(sizeof(struct snake_ladder), 1);
    ladder->length = length;
    ladder->direction = FORWARDS;

    return ladder;
}


// Places a snake/ladder onto the board
int place_snake_ladder(board_t board, int index, snake_ladder_t snake_ladder) {
    cell_t cell = get_cell(board, index), // get the cell with the specified index
    dest;

    if (cell != NULL && cell->snake_ladder == 0) {
        // get the cell located snake_ladder->length ahead/behind the selected cell
        dest = next_steps(board, cell,
                          snake_ladder->direction == BACKWARDS ? -snake_ladder->length : snake_ladder->length);

        /*
            returns 0 when:
                            - the destination cell exists
                            - a ladder/snake that leads back to the selected
                            - cell does not exist. This would
                            - a circular/infinite loop
         */

        // confirms that the destination cell exists
        if (dest) {
            // if no snake/ladder exists at the destination cell or a circular loop
            // is not created
            if (dest->snake_ladder == 0 || dest->snake_ladder->cell->index != index) {
                cell->snake_ladder = snake_ladder;
                cell->snake_ladder->cell = dest;

                return 0;
            }
        }
    }

    return -1;
}


// Get the cell on the board with the specified index
cell_t get_cell(board_t board, int index) {
    cell_t cell;
    cell = board->cells;

    while (cell != NULL) {
        // loop through the cells linked list while comparing the
        // index
        if (cell->index == index)
            return cell;

        cell = cell->next;
    }

    return NULL;
}


// Determines the cell located steps - steps away from
// the specified cell
cell_t next_steps(board_t board, cell_t cell, int steps) {
    cell_t forward, current;
    if (steps > 0) {
        /*
            if the cell is located in a forward position,
            traverse the linked list starting from the current cell
         */
        while (cell != 0 && steps != 0) {
            cell = cell->next;
            steps--;
        }
    } else {
        /*
            if the cell is located in a backwards/preceding position,
            traverse the linked list starting from the
            beginning of the board
         */
        current = forward = board->cells;

        /*
            begin by creating a "window" where the first cell should
            be the destination and the end should match the current cell
         */
        while (forward != 0 && steps != 0) {
            forward = forward->next;
            steps++;
        }

        /*
            continue until the first cell in the window matches the
            current cell.
            Forms a moving window
        */
        while (forward != 0 && forward != cell) {
            forward = forward->next;
            current = current->next;
        }

        cell = forward != 0 ? current : forward;
    }

    return cell;
}
