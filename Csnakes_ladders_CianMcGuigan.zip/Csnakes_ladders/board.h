#ifndef _BOARD_H_
#define _BOARD_H_

typedef struct cell *cell_t;
typedef struct board *board_t;
typedef struct snake_ladder *snake_ladder_t;
typedef snake_ladder_t snake_t;
typedef snake_ladder_t ladder_t;

typedef enum {FORWARDS , BACKWARDS} DIRECTION;

struct snake_ladder {
    cell_t cell;
    int length;
    DIRECTION direction;
};

struct board {
    int size;
    cell_t cells;
};

struct cell {
    int index;
    cell_t next;
    //cell_t *snake_or_ladder;
    union {
        snake_ladder_t snake_ladder;
        snake_t snake;
        ladder_t ladder;
    };
};

board_t init_board(int size);
cell_t init_cell(int index);
snake_t init_snake(int length);
ladder_t init_ladder(int length);

int place_snake_ladder(board_t board , int index , snake_ladder_t snake_ladder);
cell_t get_cell(board_t board , int cell);
cell_t next_steps(board_t board , cell_t cell , int steps);

#endif
