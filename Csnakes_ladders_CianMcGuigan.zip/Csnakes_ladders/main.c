#include <stdio.h>
#include <stdlib.h>
#include "board.h"
#include "game.h"
#include "log.h"

#define BOARD_MIN 32
#define BOARD_MAX 64
#define LOG_FILE "log.txt"

// Function to print out program usage
void usage(char *argv[]) {
    printf("Usage: %s snakes ladders\n", argv[0]);
}

int main(int argc, char *argv[]) {
    int size, state, steps, i, j;
    board_t board;
    cursor cursor;
    snake_ladder_t snake_ladder;

    // check argument count
    if (argc < 3) {
        // if it is incorrect print out the usage message and exit
        usage(argv);
        return EXIT_FAILURE;
    }

    // loop that check the snakes and ladders command line arguments' types
    for (i = 1, j = 0; i <= 2; i++, j = 0) {
        // iterate over the strings and check for non numeric characters
        while (argv[i][j] != '\0' && argv[i][j] >= '0' && argv[i][j] <= '9')
            j++;

        if (argv[i][j] != '\0') {
            /*
                if the string contains a non-numeric character print out the usage
                message and exit
            */
            fprintf(stderr, "Argument %d requires an integer\n", i);
            usage(argv);
            return EXIT_FAILURE;
        }
    }

    // open log
    open_log(LOG_FILE);

    // randomly determines the board size
    size = BOARD_MIN + rand() % (1 + BOARD_MAX - BOARD_MIN);


    // initialize board
    log_line("Initializing board size: %d", size);
    board = init_board(size);

    // initialize player cursor
    init_cursor(board, &cursor);
    log_line("Cursor initialized to cell %d", cursor.cell->index);

    /*
        extract number of snakes to add to the board
     */
    i = atoi(argv[1]);
    log_line("Adding %d snake(s) to the board", i);
    for (; i > 0; i--) {
        // the size of snake is randomly chosen between 1-10
        size = 1 + rand() % 10;

        // create/initialize snake
        snake_ladder = init_snake(size);
        do {
            /*
                randomly determine the index in the board at which to
                add the snake
            */
            j = 1 + rand() % board->size;

            // attempt to add the snake at the chosen location
            state = place_snake_ladder(board, j, snake_ladder);
            log_line(
                    "Attempt to add %d unit(s) long snake at cell %d %s",
                    size,
                    j,
                    state >= 0 ? "successful" : "failed"
            );
        } while (state < 0); // loop while addition attempt at the index fails
    }


    // extract number of ladders to add to the board

    i = atoi(argv[2]);
    log_line("Adding %d ladders(s) to the board", i);
    for (; i > 0; i--) {
        // the size of ladder is randomly chosen between 1-10
        size = 1 + rand() % 10;

        // create/initialize ladder
        snake_ladder = init_ladder(size);
        do {
            /*
                randomly determine the index in the board at which to
                add the ladder
            */
            j = 1 + rand() % board->size;

            // attempt to add the ladder at the chosen location
            state = place_snake_ladder(board, j, snake_ladder);
            log_line(
                    "Attempt to add %d unit(s) long ladder at cell %d %s",
                    size,
                    j,
                    state >= 0 ? "successful" : "failed"
            );
        } while (state < 0);// loop while addition attempt at the index fails
    }

    log_line("GAME START");
    while (state >= 0) {
        // roll the dice
        steps = roll_dice();
        log_line("Dice rolled %d", steps);

        // move the cursor by the number of rolled steps
        state = move(board, &cursor, steps);
        if (cursor.cell) {
            /*
                if the cursor has not gone past the board,
                print the current cell index
            */
            log_line("Current cell position: %d", cursor.cell->index);
        }
    }
    log_line("GAME COMPLETED");

    return 0;
}
