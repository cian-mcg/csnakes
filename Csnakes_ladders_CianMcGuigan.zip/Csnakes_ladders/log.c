#include <stdio.h>
#include <stdarg.h>
#include "log.h"

// log file
FILE *logfile = 0;

int open_log(char *logpath) {
    // return error status if the log file is already open
    if (logfile)
        return -1;

    // open the log file
#ifndef LOGFILE_APPEND
    logfile = fopen(logpath, "w");
#else
    logfile = fopen(logpath , "a");
#endif

    if (!logfile)
        return -1;
    return 0;
}

static int _log_line(FILE *file, char *fmt, va_list args) {
    // write the string to the file and store the return status
    int ret = vfprintf(file, fmt, args);
    if (ret >= 0) {
        // append a new line if write was successful
        fputs("\n", file);
    }

    // return stored return status
    return ret;
}


// writes a line of text to the log output
int log_line(char *fmt, ...) {
    va_list args;
    int ret = 0;

    va_start(args, fmt);
    if (logfile) {
        ret = _log_line(logfile, fmt, args);
    }

        // writes the same log line to standard output if enabled
#ifdef LOG_STDOUT
        _log_line(stdout , fmt , args);
#endif

    va_end(args);

    return ret;
}

// closes the log file(if it is open)
int close_log() {
    int ret = 0;

    // check if the log file is open
    if (!logfile) {
        ret = fclose(logfile);
        logfile = 0;
    }
    return ret;
}

