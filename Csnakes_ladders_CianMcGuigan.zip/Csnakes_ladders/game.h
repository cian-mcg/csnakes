#ifndef _GAME_H_
#define _GAME_H_

#define DICE_MIN 1
#define DICE_MAX 6

typedef struct cursor {
    cell_t cell;
} cursor;

int init_cursor(board_t board , cursor *cursor);
int roll_dice();
int move(board_t board , cursor *player , int steps);

#endif
