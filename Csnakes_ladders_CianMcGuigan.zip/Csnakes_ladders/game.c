#include <stdlib.h>
#include "board.h"
#include "game.h"
#include "log.h"

int init_cursor(board_t board, cursor *cursor) {
    cursor->cell = board->cells;

    return 0;
}


// function to roll the dice
int roll_dice() {
    return DICE_MIN + rand() % (1 + DICE_MAX - DICE_MIN);
}


// moves the cursor on the board by the specified number of steps
int move(board_t board, cursor *player, int steps) {
    cell_t cell;

    cell = next_steps(board, player->cell, steps);

    while (cell != 0 && cell->snake_ladder != 0) {
        log_line(
                "Found %s at cell %d while moving",
                cell->snake_ladder->direction == BACKWARDS
                ? "snake" : "lader",
                cell->index
        );
        cell = cell->snake_ladder->cell;
    }

    player->cell = cell;
    if (cell == 0) {
        log_line("Went past the last square");
        return -1;
    }

    if (cell->next == 0) {
        log_line("At the last square");
        return -1;
    }

    return 0;
}
